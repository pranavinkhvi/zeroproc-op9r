# ZeroProc OP9R (Camera2 Zero-Processing Camera App)

Native Android (Kotlin + Camera2 API) camera app built specifically for the **OnePlus 9R** (`lemonades` / Snapdragon 870).

## What It Strips Out
- **Zero ISP Post-Processing:** Forces `NOISE_REDUCTION_MODE_OFF`, `EDGE_MODE_OFF`, `HOT_PIXEL_MODE_OFF`, `SHADING_MODE_OFF`, `COLOR_CORRECTION_ABERRATION_MODE_OFF`, and disables HDR/scene modes.
- **True RAW DNG (`ImageFormat.RAW_SENSOR`):** Captures 10-bit Bayer DNG directly off the Sony IMX586 (Main) and IMX481 (Ultrawide) sensors into `DCIM/ZeroProc/`.
- **OxygenOS Auxiliary Lens Whitelist:** Pre-configured with `applicationId = "org.codeaurora.snapcam"` so stock OxygenOS exposes auxiliary camera IDs without root. *(If you already have a Snapcam GCam installed, change `applicationId` in `app/build.gradle.kts` to `"com.ss.android.ugc.aweme"`.)*
- **Full Manual Controls:** Independent logarithmic sliders for ISO, Shutter Speed (up to max HAL exposure), Focus (diopters), White Balance (Kelvin -> RGBG matrix), OIS toggle, Flat/Linear tonemap curve, and Max-Res (48MP) request mode.
- **Uncapped Video:** HEVC (H.265) up to **200 Mbps** with zero NR/sharpening and optional flat linear curve.
- **Live RGB Histogram:** Samples preview frames on the UI thread without consuming an extra Camera2 hardware stream.

## Build the Installable APK Without a PC (GitHub Actions — Free, ~2 Minutes)
1. Extract this ZIP.
2. Create a new repository on GitHub (private or public) and upload all extracted files (make sure `.github/workflows/build-apk.yml` is included).
3. Open the **Actions** tab in your GitHub repo -> select **Build ZeroProc OP9R APK** -> tap **Run workflow** (or it starts automatically on push).
4. Once green (~2 minutes), scroll to **Artifacts** and download **`ZeroProc-OP9R-APK`**, unzip it, and install `ZeroProc-OP9R-v1.0.apk`.

## OnePlus 9R Hardware / Root Notes
- **Stock OxygenOS (Unrooted):** Main IMX586 outputs 12MP binned `RAW_SENSOR` DNG and OxygenOS caps certain third-party long exposures in vendor HAL.
- **Rooted / Custom ROM (LineageOS, Evolution X, or Magisk):** Flashing the community *OnePlus 8 Series & 9R Camera Unlocker* Magisk module removes the vendor shutter cap and unlocks full **48MP RAW10** on the IMX586—then toggle **MAX-RES: ON** inside ZeroProc.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zeroproc.camera"
    compileSdk = 34

    defaultConfig {
        // Whitelisted OnePlus/Qualcomm Snapcam package ID so stock OxygenOS exposes auxiliary lenses without root.
        // If you already have a Snapcam GCam installed, swap this to "com.ss.android.ugc.aweme" or "com.zeroproc.camera".
        applicationId = "org.codeaurora.snapcam"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-OP9R"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

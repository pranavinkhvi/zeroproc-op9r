package com.zeroproc.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.TonemapCurve
import android.media.ExifInterface
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

data class ZeroProcSettings(
    var zeroProcessing: Boolean = true,
    var rawOnly: Boolean = true,
    var flatLinearTone: Boolean = false,
    var oisEnabled: Boolean = true,
    var maxResMode: Boolean = false,
    var videoMode: Boolean = false,
    var videoBitrateMbps: Int = 150,
    var manualIso: Int? = null,
    var manualExposureNs: Long? = null,
    var manualFocusDiopter: Float? = null,
    var manualWbKelvin: Int? = null
)

class ZeroProcEngine(
    private val context: Context,
    private val textureView: TextureView,
    private val onStatus: (String) -> Unit,
    private val onTelemetry: (String) -> Unit,
    private val onRecordingStateChanged: (Boolean) -> Unit
) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null
    private val bgExecutor = Executor { runnable -> bgHandler?.post(runnable) }

    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var previewBuilder: CaptureRequest.Builder? = null
    private var rawReader: ImageReader? = null
    private var jpegReader: ImageReader? = null

    private var mediaRecorder: MediaRecorder? = null
    private var videoPfd: ParcelFileDescriptor? = null
    private var pendingStartRecording: Boolean = false
    private var activeVideoSize: Size = Size(3840, 2160)
    var isRecording: Boolean = false
        private set

    var activeLens: CameraLensInfo? = null
        private set
    private var activeCharacteristics: CameraCharacteristics? = null
    val settings = ZeroProcSettings()

    private val pendingRawImages = ConcurrentHashMap<Long, Image>()
    private val pendingResults = ConcurrentHashMap<Long, TotalCaptureResult>()

    private var lastReportedIso: Int = 0
    private var lastReportedExposureNs: Long = 0L

    fun startThread() {
        if (bgThread == null) {
            bgThread = HandlerThread("ZeroProcCameraThread").apply { start() }
            bgHandler = Handler(bgThread!!.looper)
        }
    }

    fun stopThread() {
        closeCamera()
        bgThread?.quitSafely()
        try {
            bgThread?.join()
        } catch (_: InterruptedException) {
        }
        bgThread = null
        bgHandler = null
    }

    @SuppressLint("MissingPermission")
    fun openLens(lens: CameraLensInfo) {
        closeCamera()
        activeLens = lens
        activeCharacteristics = cameraManager.getCameraCharacteristics(lens.id)
        onStatus("Opening ${lens.label}...")

        try {
            cameraManager.openCamera(lens.id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    createSession()
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                    onStatus("Camera disconnected")
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    onStatus("Camera HAL error: $error")
                }
            }, bgHandler)
        } catch (e: Exception) {
            onStatus("HAL blocked ${lens.label}: ${e.message}")
        }
    }

    fun reconfigureSession() {
        if (cameraDevice != null) {
            createSession()
        }
    }

    private fun createSession() {
        val camera = cameraDevice ?: return
        val lens = activeLens ?: return
        val chars = activeCharacteristics ?: return
        val surfaceTexture = textureView.surfaceTexture ?: return

        closeSessionOnly()

        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val previewSizes = map.getOutputSizes(SurfaceTexture::class.java)
        val previewSize = chooseOptimalPreviewSize(previewSizes)
        surfaceTexture.setDefaultBufferSize(previewSize.width, previewSize.height)
        applyCenterCropTransform(previewSize)
        val previewSurface = Surface(surfaceTexture)

        val outputConfigs = mutableListOf(OutputConfiguration(previewSurface))

        if (!settings.videoMode) {
            val targetRawSize = if (settings.maxResMode && lens.maxResRawSize != null) {
                lens.maxResRawSize
            } else {
                lens.rawSize
            }

            if (lens.supportsRaw && targetRawSize != null) {
                rawReader = ImageReader.newInstance(
                    targetRawSize.width,
                    targetRawSize.height,
                    ImageFormat.RAW_SENSOR,
                    3
                ).apply {
                    setOnImageAvailableListener({ reader ->
                        val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                        handleRawImage(img)
                    }, bgHandler)
                }
                outputConfigs.add(OutputConfiguration(rawReader!!.surface))
            }

            if (!settings.rawOnly || !lens.supportsRaw) {
                val jpegSize = lens.jpegSize ?: Size(4000, 3000)
                jpegReader = ImageReader.newInstance(
                    jpegSize.width,
                    jpegSize.height,
                    ImageFormat.JPEG,
                    2
                ).apply {
                    setOnImageAvailableListener({ reader ->
                        val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                        saveJpegImage(img)
                    }, bgHandler)
                }
                outputConfigs.add(OutputConfiguration(jpegReader!!.surface))
            }
        } else {
            mediaRecorder?.surface?.let { recSurface ->
                outputConfigs.add(OutputConfiguration(recSurface))
            }
        }

        val sessionCallback = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                startRepeatingPreview(previewSurface)

                if (pendingStartRecording && mediaRecorder != null) {
                    pendingStartRecording = false
                    try {
                        mediaRecorder?.start()
                        isRecording = true
                        onRecordingStateChanged(true)
                        onStatus("REC ${activeVideoSize.width}x${activeVideoSize.height} @ ${settings.videoBitrateMbps}Mbps HEVC")
                    } catch (e: Exception) {
                        isRecording = false
                        onRecordingStateChanged(false)
                        cleanupRecorder()
                        onStatus("Recorder start failed: ${e.message}")
                    }
                    return
                }

                val streamInfo = if (settings.videoMode) {
                    "VIDEO ${settings.videoBitrateMbps}Mbps"
                } else if (lens.supportsRaw) {
                    val sz = if (settings.maxResMode && lens.maxResRawSize != null) lens.maxResRawSize else lens.rawSize
                    "RAW ${sz?.width}x${sz?.height}"
                } else {
                    "YUV/JPG ONLY (NO RAW ON LENS)"
                }
                onStatus("${lens.label} // $streamInfo")
                pushTelemetry()
            }

            override fun onConfigureFailed(session: CameraCaptureSession) {
                pendingStartRecording = false
                if (isRecording) {
                    isRecording = false
                    onRecordingStateChanged(false)
                    cleanupRecorder()
                }
                onStatus("Session failed on ${lens.label} (try disabling Max-Res or RAW+JPG)")
            }
        }

        try {
            val config = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                outputConfigs,
                bgExecutor,
                sessionCallback
            )
            camera.createCaptureSession(config)
        } catch (e: Exception) {
            pendingStartRecording = false
            onStatus("Config error: ${e.message}")
        }
    }

    private fun applyCenterCropTransform(bufferSize: Size) {
        textureView.post {
            val viewW = textureView.width.toFloat()
            val viewH = textureView.height.toFloat()
            if (viewW <= 0f || viewH <= 0f) return@post

            // Camera sensor buffer is landscape; portrait view swaps width/height
            val bufPortraitW = bufferSize.height.toFloat()
            val bufPortraitH = bufferSize.width.toFloat()
            val scale = max(viewW / bufPortraitW, viewH / bufPortraitH)
            val scaledW = bufPortraitW * scale
            val scaledH = bufPortraitH * scale

            val matrix = Matrix()
            matrix.setScale(scaledW / viewW, scaledH / viewH, viewW / 2f, viewH / 2f)
            textureView.setTransform(matrix)
        }
    }

    private fun startRepeatingPreview(previewSurface: Surface) {
        val camera = cameraDevice ?: return
        val session = captureSession ?: return
        val template = if (settings.videoMode) {
            CameraDevice.TEMPLATE_RECORD
        } else {
            CameraDevice.TEMPLATE_MANUAL
        }

        previewBuilder = try {
            camera.createCaptureRequest(template)
        } catch (_: Exception) {
            camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        }

        previewBuilder?.addTarget(previewSurface)
        if (settings.videoMode && (pendingStartRecording || isRecording)) {
            mediaRecorder?.surface?.let { previewBuilder?.addTarget(it) }
        }

        applyHardwareOverrides(previewBuilder!!)
        try {
            session.setRepeatingRequest(
                previewBuilder!!.build(),
                object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(
                        session: CameraCaptureSession,
                        request: CaptureRequest,
                        result: TotalCaptureResult
                    ) {
                        lastReportedIso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: lastReportedIso
                        lastReportedExposureNs = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: lastReportedExposureNs
                    }
                },
                bgHandler
            )
        } catch (e: Exception) {
            onStatus("Preview error: ${e.message}")
        }
    }

    fun updateLiveControls() {
        val session = captureSession ?: return
        val builder = previewBuilder ?: return
        applyHardwareOverrides(builder)
        try {
            session.setRepeatingRequest(builder.build(), null, bgHandler)
            pushTelemetry()
        } catch (e: Exception) {
            onStatus("Control update rejected: ${e.message}")
        }
    }

    private fun applyHardwareOverrides(builder: CaptureRequest.Builder) {
        val lens = activeLens ?: return

        builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        builder.set(CaptureRequest.CONTROL_SCENE_MODE, CaptureRequest.CONTROL_SCENE_MODE_DISABLED)
        builder.set(CaptureRequest.CONTROL_EFFECT_MODE, CaptureRequest.CONTROL_EFFECT_MODE_OFF)

        if (settings.zeroProcessing) {
            builder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            builder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
            builder.set(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_OFF)
            builder.set(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_OFF)
            builder.set(
                CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_OFF
            )
            builder.set(
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            )
        } else {
            builder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_FAST)
            builder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_FAST)
            builder.set(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_FAST)
        }

        if (lens.supportsOis) {
            builder.set(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                if (settings.oisEnabled) CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
            )
        }

        if (settings.flatLinearTone && lens.supportsLinearTonemap) {
            builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE)
            val flatCurve = floatArrayOf(
                0.00f, 0.00f,
                0.15f, 0.24f,
                0.35f, 0.48f,
                0.65f, 0.75f,
                1.00f, 1.00f
            )
            builder.set(
                CaptureRequest.TONEMAP_CURVE,
                TonemapCurve(flatCurve, flatCurve, flatCurve)
            )
        } else {
            builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_FAST)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.set(
                CaptureRequest.SENSOR_PIXEL_MODE,
                if (settings.maxResMode) CaptureRequest.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION
                else CaptureRequest.SENSOR_PIXEL_MODE_DEFAULT
            )
        }

        if (settings.manualIso != null || settings.manualExposureNs != null) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            val iso = (settings.manualIso ?: lastReportedIso.takeIf { it > 0 } ?: 100)
                .coerceIn(lens.isoRange.lower, lens.isoRange.upper)
            val exp = (settings.manualExposureNs ?: lastReportedExposureNs.takeIf { it > 0L } ?: 16_666_666L)
                .coerceIn(lens.exposureRangeNs.lower, lens.exposureRangeNs.upper)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }

        if (settings.manualFocusDiopter != null && lens.minFocusDistance > 0f) {
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(
                CaptureRequest.LENS_FOCUS_DISTANCE,
                settings.manualFocusDiopter!!.coerceIn(0f, lens.minFocusDistance)
            )
        } else {
            val afMode = if (settings.videoMode) {
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
            } else {
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            }
            builder.set(CaptureRequest.CONTROL_AF_MODE, afMode)
        }

        if (settings.manualWbKelvin != null) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            builder.set(
                CaptureRequest.COLOR_CORRECTION_MODE,
                CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX
            )
            builder.set(
                CaptureRequest.COLOR_CORRECTION_GAINS,
                kelvinToRggb(settings.manualWbKelvin!!)
            )
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }
    }

    fun captureStill() {
        val camera = cameraDevice ?: return
        val session = captureSession ?: return
        val lens = activeLens ?: return

        val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        applyHardwareOverrides(builder)
        builder.set(CaptureRequest.JPEG_ORIENTATION, lens.sensorOrientation)
        builder.set(CaptureRequest.JPEG_QUALITY, 100.toByte())

        var hasTarget = false
        rawReader?.surface?.let {
            builder.addTarget(it)
            hasTarget = true
        }
        if (!settings.rawOnly || !lens.supportsRaw) {
            jpegReader?.surface?.let {
                builder.addTarget(it)
                hasTarget = true
            }
        }
        if (!hasTarget) {
            onStatus("No capture surface available")
            return
        }

        onStatus("Capturing...")
        session.capture(
            builder.build(),
            object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    val ts = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
                    val rawImg = pendingRawImages.remove(ts)
                    if (rawImg != null) {
                        writeDngFile(rawImg, result)
                    } else {
                        pendingResults[ts] = result
                        pruneStaleBuffers()
                    }
                }
            },
            bgHandler
        )
    }

    private fun handleRawImage(image: Image) {
        val ts = image.timestamp
        val result = pendingResults.remove(ts)
        if (result != null) {
            writeDngFile(image, result)
        } else {
            pendingRawImages[ts] = image
            pruneStaleBuffers()
        }
    }

    private fun pruneStaleBuffers() {
        if (pendingRawImages.size > 4) {
            val oldest = pendingRawImages.keys.minOrNull() ?: return
            pendingRawImages.remove(oldest)?.close()
        }
        if (pendingResults.size > 8) {
            val oldest = pendingResults.keys.minOrNull() ?: return
            pendingResults.remove(oldest)
        }
    }

    private fun writeDngFile(image: Image, result: TotalCaptureResult) {
        val chars = activeCharacteristics
        val lens = activeLens
        if (chars == null || lens == null) {
            image.close()
            return
        }
        val tsStr = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val name = "ZP_${lens.id}_$tsStr.dng"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/ZeroProc")
        }

        val exifOrientation = when (lens.sensorOrientation) {
            90 -> ExifInterface.ORIENTATION_ROTATE_90
            180 -> ExifInterface.ORIENTATION_ROTATE_180
            270 -> ExifInterface.ORIENTATION_ROTATE_270
            else -> ExifInterface.ORIENTATION_NORMAL
        }

        try {
            val uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            )
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    DngCreator(chars, result).use { dng ->
                        dng.setOrientation(exifOrientation)
                        dng.writeImage(out, image)
                    }
                }
                onStatus("Saved RAW DNG: $name")
            }
        } catch (e: Exception) {
            onStatus("DNG write error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun saveJpegImage(image: Image) {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        image.close()

        val tsStr = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val name = "ZP_${activeLens?.id ?: "0"}_$tsStr.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/ZeroProc")
        }
        try {
            val uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            )
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                onStatus("Saved JPG: $name")
            }
        } catch (e: Exception) {
            onStatus("JPG error: ${e.message}")
        }
    }

    fun toggleVideoRecording() {
        if (isRecording) {
            stopRecording()
        } else {
            startRecording()
        }
    }

    private fun startRecording() {
        val lens = activeLens ?: return
        val chars = activeCharacteristics ?: return
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return

        val vidSizes = map.getOutputSizes(MediaRecorder::class.java)
        activeVideoSize = vidSizes.firstOrNull { it.width == 3840 && it.height == 2160 }
            ?: vidSizes.firstOrNull { it.width == 1920 && it.height == 1080 }
            ?: vidSizes.maxByOrNull { it.width * it.height }
            ?: Size(1920, 1080)

        val tsStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "ZP_VID_${lens.id}_${settings.videoBitrateMbps}M_$tsStr.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/ZeroProc")
        }

        try {
            val uri = context.contentResolver.insert(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                values
            ) ?: throw IllegalStateException("Failed to create MediaStore video entry")

            videoPfd = context.contentResolver.openFileDescriptor(uri, "w")
                ?: throw IllegalStateException("Failed to open video file descriptor")

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(videoPfd!!.fileDescriptor)
                setVideoEncodingBitRate(settings.videoBitrateMbps * 1_000_000)
                setVideoFrameRate(30)
                setVideoSize(activeVideoSize.width, activeVideoSize.height)
                setVideoEncoder(MediaRecorder.VideoEncoder.HEVC)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(320_000)
                setAudioSamplingRate(48_000)
                setOrientationHint(lens.sensorOrientation)
                prepare()
            }

            mediaRecorder = recorder
            pendingStartRecording = true
            createSession()
        } catch (e: Exception) {
            pendingStartRecording = false
            onStatus("Video setup error: ${e.message}")
            cleanupRecorder()
        }
    }

    private fun stopRecording() {
        isRecording = false
        pendingStartRecording = false
        onRecordingStateChanged(false)
        try {
            mediaRecorder?.stop()
            onStatus("Saved uncapped video to DCIM/ZeroProc")
        } catch (e: Exception) {
            onStatus("Stopped recording (${e.message})")
        } finally {
            cleanupRecorder()
            createSession()
        }
    }

    private fun cleanupRecorder() {
        try {
            mediaRecorder?.reset()
            mediaRecorder?.release()
        } catch (_: Exception) {
        }
        mediaRecorder = null
        try {
            videoPfd?.close()
        } catch (_: Exception) {
        }
        videoPfd = null
    }

    private fun pushTelemetry() {
        val lens = activeLens ?: return
        val maxSec = lens.exposureRangeNs.upper / 1_000_000_000.0
        val rawDesc = if (lens.supportsRaw) {
            val s = if (settings.maxResMode && lens.maxResRawSize != null) lens.maxResRawSize else lens.rawSize
            "${s?.width}x${s?.height} RAW_SENSOR"
        } else {
            "NO RAW_SENSOR"
        }
        val text = buildString {
            append("HAL: Camera2 (${lens.hardwareLevelName}) | ID ${lens.id}
")
            append("RAW: $rawDesc
")
            append("ISO: ${lens.isoRange.lower}-${lens.isoRange.upper} | MAX EXP: ${String.format("%.1fs", maxSec)}")
        }
        onTelemetry(text)
    }

    private fun chooseOptimalPreviewSize(sizes: Array<Size>): Size {
        return sizes
            .filter { it.width <= 1920 && it.height <= 1080 }
            .maxByOrNull { it.width * it.height }
            ?: sizes.first()
    }

    private fun kelvinToRggb(kelvin: Int): RggbChannelVector {
        val temp = (kelvin.coerceIn(2000, 10000)) / 100.0
        val red = if (temp <= 66.0) 255.0 else (329.698727446 * (temp - 60.0).pow(-0.1332047592)).coerceIn(0.0, 255.0)
        val green = if (temp <= 66.0) {
            (99.4708025861 * ln(temp) - 161.1195681661).coerceIn(0.0, 255.0)
        } else {
            (288.1221695283 * (temp - 60.0).pow(-0.0755148492)).coerceIn(0.0, 255.0)
        }
        val blue = when {
            temp >= 66.0 -> 255.0
            temp <= 19.0 -> 0.0
            else -> (138.5177312231 * ln(temp - 10.0) - 305.0447927307).coerceIn(0.0, 255.0)
        }
        val rGain = (red / 128.0).toFloat().coerceIn(0.5f, 3.5f)
        val gGain = (green / 128.0).toFloat().coerceIn(0.5f, 3.5f)
        val bGain = (blue / 128.0).toFloat().coerceIn(0.5f, 3.5f)
        return RggbChannelVector(rGain, gGain, gGain, bGain)
    }

    private fun closeSessionOnly() {
        try {
            captureSession?.close()
        } catch (_: Exception) {
        }
        captureSession = null
        rawReader?.close()
        rawReader = null
        jpegReader?.close()
        jpegReader = null
        pendingRawImages.values.forEach { it.close() }
        pendingRawImages.clear()
        pendingResults.clear()
    }

    fun closeCamera() {
        pendingStartRecording = false
        if (isRecording) {
            isRecording = false
            onRecordingStateChanged(false)
            cleanupRecorder()
        }
        closeSessionOnly()
        try {
            cameraDevice?.close()
        } catch (_: Exception) {
        }
        cameraDevice = null
    }
}

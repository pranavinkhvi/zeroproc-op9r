package com.zeroproc.camera

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.TextureView
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.zeroproc.camera.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.exp
import kotlin.math.ln

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var engine: ZeroProcEngine
    private var lenses: List<CameraLensInfo> = emptyList()
    private var activeParam: ManualParam? = null
    private val bitrateSteps = listOf(50, 100, 150, 200)
    private var bitrateIdx = 2

    private enum class ManualParam { ISO, SHUTTER, FOCUS, WB }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.CAMERA] == true) {
            initHardware()
        } else {
            binding.tvStatusOverlay.text = "Camera permission required"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = ZeroProcEngine(
            context = this,
            textureView = binding.viewfinder,
            onStatus = { msg -> runOnUiThread { binding.tvStatusOverlay.text = msg } },
            onTelemetry = { info -> runOnUiThread { binding.tvSensorTelemetry.text = info } },
            onRecordingStateChanged = { runOnUiThread { updateShutterAppearance() } }
        )

        setupControls()
        startHistogramAndStorageLoop()
    }

    override fun onResume() {
        super.onResume()
        engine.startThread()
        if (hasPermissions()) {
            if (binding.viewfinder.isAvailable) {
                initHardware()
            } else {
                binding.viewfinder.surfaceTextureListener = surfaceListener
            }
        } else {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    override fun onPause() {
        engine.stopThread()
        super.onPause()
    }

    private val surfaceListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            initHardware()
        }
        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
    }

    private fun hasPermissions(): Boolean {
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val aud = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        return cam && aud
    }

    private fun initHardware() {
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        lenses = CameraHardwareProbe.probeAllLenses(manager)
        buildLensButtons()
        lenses.firstOrNull()?.let { engine.openLens(it) }
    }

    private fun buildLensButtons() {
        binding.lensContainer.removeAllViews()
        lenses.forEachIndexed { idx, lens ->
            val tv = TextView(this).apply {
                text = lens.label
                textSize = 10f
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(24, 12, 24, 12)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                setBackgroundResource(if (idx == 0) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginEnd = 12
                }
                setOnClickListener {
                    highlightLensButton(idx)
                    resetManualValuesForNewLens()
                    engine.openLens(lens)
                }
            }
            binding.lensContainer.addView(tv)
        }
    }

    private fun highlightLensButton(selectedIdx: Int) {
        for (i in 0 until binding.lensContainer.childCount) {
            binding.lensContainer.getChildAt(i).setBackgroundResource(
                if (i == selectedIdx) R.drawable.bg_pill_active else R.drawable.bg_pill_dark
            )
        }
    }

    private fun resetManualValuesForNewLens() {
        engine.settings.manualIso = null
        engine.settings.manualExposureNs = null
        engine.settings.manualFocusDiopter = null
        engine.settings.manualWbKelvin = null
        refreshManualTabs()
    }

    private fun setupControls() {
        binding.btnShutter.setOnClickListener {
            if (engine.settings.videoMode) {
                engine.toggleVideoRecording()
                updateShutterAppearance()
            } else {
                engine.captureStill()
            }
        }

        binding.btnModePhoto.setOnClickListener {
            if (engine.isRecording) return@setOnClickListener
            engine.settings.videoMode = false
            updateModeButtons()
            engine.reconfigureSession()
        }

        binding.btnModeVideo.setOnClickListener {
            if (engine.isRecording) return@setOnClickListener
            engine.settings.videoMode = true
            updateModeButtons()
            engine.reconfigureSession()
        }

        binding.btnToggleZeroProc.setOnClickListener {
            engine.settings.zeroProcessing = !engine.settings.zeroProcessing
            val on = engine.settings.zeroProcessing
            binding.btnToggleZeroProc.text = if (on) "NO NR/EDGE: ON" else "NO NR/EDGE: OFF"
            binding.btnToggleZeroProc.setBackgroundResource(if (on) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
            binding.tvBypassBadge.text = if (on) "ISP BYPASS: ON" else "ISP BYPASS: OFF"
            engine.updateLiveControls()
        }

        binding.btnToggleRawOnly.setOnClickListener {
            engine.settings.rawOnly = !engine.settings.rawOnly
            val rawOnly = engine.settings.rawOnly
            binding.btnToggleRawOnly.text = if (rawOnly) "RAW ONLY" else "RAW + JPG"
            binding.tvFormatBadge.text = if (rawOnly) "RAW DNG" else "RAW + JPG"
            engine.reconfigureSession()
        }

        binding.btnToggleFlatTone.setOnClickListener {
            engine.settings.flatLinearTone = !engine.settings.flatLinearTone
            val flat = engine.settings.flatLinearTone
            binding.btnToggleFlatTone.text = if (flat) "FLAT LINEAR: ON" else "FLAT LINEAR: OFF"
            binding.btnToggleFlatTone.setBackgroundResource(if (flat) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
            engine.updateLiveControls()
        }

        binding.btnToggleOis.setOnClickListener {
            engine.settings.oisEnabled = !engine.settings.oisEnabled
            val ois = engine.settings.oisEnabled
            binding.btnToggleOis.text = if (ois) "OIS: ON" else "OIS: OFF"
            binding.btnToggleOis.setBackgroundResource(if (ois) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
            engine.updateLiveControls()
        }

        binding.btnToggleMaxRes.setOnClickListener {
            engine.settings.maxResMode = !engine.settings.maxResMode
            val maxRes = engine.settings.maxResMode
            binding.btnToggleMaxRes.text = if (maxRes) "MAX-RES: ON" else "MAX-RES: OFF"
            binding.btnToggleMaxRes.setBackgroundResource(if (maxRes) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
            engine.reconfigureSession()
        }

        binding.btnBitrate.setOnClickListener {
            bitrateIdx = (bitrateIdx + 1) % bitrateSteps.size
            val mbps = bitrateSteps[bitrateIdx]
            engine.settings.videoBitrateMbps = mbps
            binding.btnBitrate.text = "VID: ${mbps}Mbps"
            binding.tvFooterLeft.text = "BITRATE: ${mbps}Mbps HEVC"
        }

        binding.tabIso.setOnClickListener { selectManualParam(ManualParam.ISO) }
        binding.tabShutter.setOnClickListener { selectManualParam(ManualParam.SHUTTER) }
        binding.tabFocus.setOnClickListener { selectManualParam(ManualParam.FOCUS) }
        binding.tabWb.setOnClickListener { selectManualParam(ManualParam.WB) }

        binding.btnParamAuto.setOnClickListener {
            when (activeParam) {
                ManualParam.ISO -> engine.settings.manualIso = null
                ManualParam.SHUTTER -> engine.settings.manualExposureNs = null
                ManualParam.FOCUS -> engine.settings.manualFocusDiopter = null
                ManualParam.WB -> engine.settings.manualWbKelvin = null
                null -> {}
            }
            binding.tvParamValue.text = "AUTO"
            refreshManualTabs()
            engine.updateLiveControls()
        }

        binding.seekManualParam.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val lens = engine.activeLens ?: return
                val frac = progress / 1000.0
                when (activeParam) {
                    ManualParam.ISO -> {
                        val minIso = lens.isoRange.lower.toDouble().coerceAtLeast(1.0)
                        val maxIso = lens.isoRange.upper.toDouble()
                        val iso = exp(ln(minIso) + frac * (ln(maxIso) - ln(minIso))).toInt()
                        engine.settings.manualIso = iso
                        binding.tvParamValue.text = "ISO $iso"
                    }
                    ManualParam.SHUTTER -> {
                        val minNs = lens.exposureRangeNs.lower.toDouble().coerceAtLeast(1000.0)
                        val maxNs = lens.exposureRangeNs.upper.toDouble()
                        val ns = exp(ln(minNs) + frac * (ln(maxNs) - ln(minNs))).toLong()
                        engine.settings.manualExposureNs = ns
                        binding.tvParamValue.text = formatShutter(ns)
                    }
                    ManualParam.FOCUS -> {
                        val diopter = (frac * lens.minFocusDistance).toFloat()
                        engine.settings.manualFocusDiopter = diopter
                        binding.tvParamValue.text = if (diopter < 0.05f) "INF" else String.format("%.2fD", diopter)
                    }
                    ManualParam.WB -> {
                        val kelvin = (2000 + frac * 8000).toInt()
                        engine.settings.manualWbKelvin = kelvin
                        binding.tvParamValue.text = "${kelvin}K"
                    }
                    null -> {}
                }
                refreshManualTabs()
                engine.updateLiveControls()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun selectManualParam(param: ManualParam) {
        if (activeParam == param && binding.sliderRow.visibility == View.VISIBLE) {
            binding.sliderRow.visibility = View.GONE
            activeParam = null
            refreshManualTabs()
            return
        }
        activeParam = param
        binding.sliderRow.visibility = View.VISIBLE
        binding.tvParamValue.text = when (param) {
            ManualParam.ISO -> engine.settings.manualIso?.let { "ISO $it" } ?: "AUTO"
            ManualParam.SHUTTER -> engine.settings.manualExposureNs?.let { formatShutter(it) } ?: "AUTO"
            ManualParam.FOCUS -> engine.settings.manualFocusDiopter?.let { String.format("%.2fD", it) } ?: "AF"
            ManualParam.WB -> engine.settings.manualWbKelvin?.let { "${it}K" } ?: "AUTO"
        }
        refreshManualTabs()
    }

    private fun refreshManualTabs() {
        binding.tabIso.text = "ISO
${engine.settings.manualIso ?: "AUTO"}"
        binding.tabShutter.text = "SHUTTER
${engine.settings.manualExposureNs?.let { formatShutter(it) } ?: "AUTO"}"
        binding.tabFocus.text = "FOCUS
${engine.settings.manualFocusDiopter?.let { if (it < 0.05f) "INF" else String.format("%.1fD", it) } ?: "AF"}"
        binding.tabWb.text = "WB
${engine.settings.manualWbKelvin?.let { "${it}K" } ?: "AUTO"}"

        binding.tabIso.setBackgroundResource(if (activeParam == ManualParam.ISO) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
        binding.tabShutter.setBackgroundResource(if (activeParam == ManualParam.SHUTTER) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
        binding.tabFocus.setBackgroundResource(if (activeParam == ManualParam.FOCUS) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
        binding.tabWb.setBackgroundResource(if (activeParam == ManualParam.WB) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
    }

    private fun updateModeButtons() {
        val vid = engine.settings.videoMode
        binding.btnModePhoto.setBackgroundResource(if (!vid) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
        binding.btnModeVideo.setBackgroundResource(if (vid) R.drawable.bg_pill_active else R.drawable.bg_pill_dark)
        updateShutterAppearance()
    }

    private fun updateShutterAppearance() {
        if (!engine.settings.videoMode) {
            binding.btnShutter.setBackgroundResource(R.drawable.bg_shutter_ring)
            binding.btnShutter.text = "RAW"
        } else if (engine.isRecording) {
            binding.btnShutter.setBackgroundResource(R.drawable.bg_shutter_rec)
            binding.btnShutter.text = "STOP"
        } else {
            binding.btnShutter.setBackgroundResource(R.drawable.bg_shutter_ring)
            binding.btnShutter.text = "REC"
        }
    }

    private fun formatShutter(ns: Long): String {
        val sec = ns / 1_000_000_000.0
        return if (sec >= 0.5) {
            String.format("%.1fs", sec)
        } else {
            val denom = (1.0 / sec).toInt().coerceAtLeast(1)
            "1/${denom}s"
        }
    }

    private fun startHistogramAndStorageLoop() {
        lifecycleScope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                val bmp = withContext(Dispatchers.Main) {
                    if (binding.viewfinder.isAvailable) binding.viewfinder.getBitmap(160, 120) else null
                }
                if (bmp != null) {
                    binding.histogramView.updateFromBitmap(bmp)
                    bmp.recycle()
                }
                if (tick % 10 == 0) {
                    val stat = StatFs(Environment.getDataDirectory().path)
                    val freeGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
                    withContext(Dispatchers.Main) {
                        binding.tvStorageFree.text = String.format("FREE: %.1f GB", freeGb)
                    }
                }
                tick++
                delay(180)
            }
        }
    }
}

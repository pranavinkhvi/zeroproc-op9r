package com.zeroproc.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class HistogramView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val redBins = IntArray(64)
    private val greenBins = IntArray(64)
    private val blueBins = IntArray(64)

    private val redPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(135, 255, 65, 65)
        style = Paint.Style.FILL
    }
    private val greenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(135, 65, 235, 110)
        style = Paint.Style.FILL
    }
    private val bluePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(135, 65, 145, 255)
        style = Paint.Style.FILL
    }
    private val gridPaint = Paint().apply {
        color = Color.argb(45, 255, 255, 255)
        strokeWidth = 1f
    }

    private val redPath = Path()
    private val greenPath = Path()
    private val bluePath = Path()

    fun updateFromBitmap(bitmap: Bitmap) {
        val r = IntArray(64)
        val g = IntArray(64)
        val b = IntArray(64)

        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        for (px in pixels) {
            r[((px shr 16) and 0xFF) shr 2]++
            g[((px shr 8) and 0xFF) shr 2]++
            b[(px and 0xFF) shr 2]++
        }

        synchronized(this) {
            r.copyInto(redBins)
            g.copyInto(greenBins)
            b.copyInto(blueBins)
        }
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        for (i in 1..3) {
            val x = w * i / 4f
            canvas.drawLine(x, 0f, x, h, gridPaint)
        }

        val rCopy = IntArray(64)
        val gCopy = IntArray(64)
        val bCopy = IntArray(64)
        synchronized(this) {
            redBins.copyInto(rCopy)
            greenBins.copyInto(gCopy)
            blueBins.copyInto(bCopy)
        }

        var maxVal = 1
        for (i in 1 until 63) {
            maxVal = max(maxVal, max(rCopy[i], max(gCopy[i], bCopy[i])))
        }

        drawChannel(canvas, bluePath, bCopy, maxVal, w, h, bluePaint)
        drawChannel(canvas, greenPath, gCopy, maxVal, w, h, greenPaint)
        drawChannel(canvas, redPath, rCopy, maxVal, w, h, redPaint)
    }

    private fun drawChannel(
        canvas: Canvas,
        path: Path,
        bins: IntArray,
        maxVal: Int,
        w: Float,
        h: Float,
        paint: Paint
    ) {
        path.reset()
        path.moveTo(0f, h)
        val step = w / 63f
        for (i in 0 until 64) {
            val norm = (bins[i].toFloat() / maxVal.toFloat()).coerceAtMost(1f)
            val x = i * step
            val y = h - (norm * (h - 6f))
            path.lineTo(x, y)
        }
        path.lineTo(w, h)
        path.close()
        canvas.drawPath(path, paint)
    }
}

package com.zeroproc.camera

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.util.Range
import android.util.Size

data class CameraLensInfo(
    val id: String,
    val label: String,
    val facing: Int,
    val hardwareLevelName: String,
    val focalLengthMm: Float,
    val supportsRaw: Boolean,
    val rawSize: Size?,
    val maxResRawSize: Size?,
    val jpegSize: Size?,
    val isoRange: Range<Int>,
    val exposureRangeNs: Range<Long>,
    val minFocusDistance: Float,
    val supportsOis: Boolean,
    val supportsLinearTonemap: Boolean,
    val sensorOrientation: Int
)

object CameraHardwareProbe {

    fun probeAllLenses(manager: CameraManager): List<CameraLensInfo> {
        val candidateIds = LinkedHashSet<String>()
        try {
            candidateIds.addAll(manager.cameraIdList)
        } catch (_: Exception) {
        }
        // Probe hidden OnePlus / Qualcomm auxiliary IDs (0..7)
        for (i in 0..7) {
            candidateIds.add(i.toString())
        }

        val lenses = mutableListOf<CameraLensInfo>()
        for (id in candidateIds) {
            val chars = try {
                manager.getCameraCharacteristics(id)
            } catch (_: Exception) {
                continue
            }

            val facing = chars.get(CameraCharacteristics.LENS_FACING)
                ?: CameraCharacteristics.LENS_FACING_BACK
            val level = chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
                ?: CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED
            val levelName = when (level) {
                CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                else -> "LEGACY"
            }

            val capabilities = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?: IntArray(0)
            val hasRawCap = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)

            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val rawSizes = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
            val bestRaw = rawSizes?.maxByOrNull { it.width.toLong() * it.height.toLong() }

            var maxResRaw: Size? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val maxMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
                val maxRawSizes = maxMap?.getOutputSizes(ImageFormat.RAW_SENSOR)
                maxResRaw = maxRawSizes?.maxByOrNull { it.width.toLong() * it.height.toLong() }
            }

            val jpegSizes = map?.getOutputSizes(ImageFormat.JPEG)
            val bestJpeg = jpegSizes?.maxByOrNull { it.width.toLong() * it.height.toLong() }

            val focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?.firstOrNull() ?: 0f

            val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                ?: Range(100, 3200)
            val expRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                ?: Range(100_000L, 1_000_000_000L)
            val minFocus = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f

            val oisModes = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?: IntArray(0)
            val supportsOis = oisModes.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)

            val tonemapModes = chars.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)
                ?: IntArray(0)
            val supportsLinear = tonemapModes.contains(CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE)

            val orientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val pixelArray = chars.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)

            val label = buildFriendlyLabel(id, facing, focal, pixelArray)

            lenses.add(
                CameraLensInfo(
                    id = id,
                    label = label,
                    facing = facing,
                    hardwareLevelName = levelName,
                    focalLengthMm = focal,
                    supportsRaw = hasRawCap && bestRaw != null,
                    rawSize = bestRaw,
                    maxResRawSize = maxResRaw,
                    jpegSize = bestJpeg,
                    isoRange = isoRange,
                    exposureRangeNs = expRange,
                    minFocusDistance = minFocus,
                    supportsOis = supportsOis,
                    supportsLinearTonemap = supportsLinear,
                    sensorOrientation = orientation
                )
            )
        }
        return lenses
    }

    private fun buildFriendlyLabel(
        id: String,
        facing: Int,
        focal: Float,
        pixelArray: Size?
    ): String {
        if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
            return "ID $id FRONT"
        }
        val mp = if (pixelArray != null) {
            ((pixelArray.width.toLong() * pixelArray.height.toLong()) / 1_000_000L).toInt()
        } else 0

        return when {
            id == "0" -> "ID $id MAIN (${mp}MP)"
            focal in 0.5f..2.6f -> "ID $id UW (${mp}MP)"
            mp in 4..6 -> "ID $id MACRO"
            mp in 1..3 -> "ID $id MONO"
            else -> "ID $id (${String.format("%.1f", focal)}mm)"
        }
    }
}
